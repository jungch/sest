

get.proportion_table <- function(beta.value=NULL, detecP=NULL, beta.intervals.X=seq(0,1,0.1), beta.intervals.Y=seq(0,1,0.1), p.intervals.X=c(-18,-5,-2,0), p.intervals.Y=c(-18,-5,-2,0), samples=NULL){
	if (is.null(dim(beta.value))) {
		beta.value <- as.matrix(beta.value)
		colnames(beta.value) <- ifelse(is.null(samples), "1", samples)
	}
	if (is.null(dim(detecP))) {
		detecP <- as.matrix(detecP)
		colnames(detecP) <- "1"
		colnames(detecP) <- ifelse(is.null(samples), "1", samples)
	}

	if (is.null(samples)) {
		samples <- colnames(beta.value)
	} else {
		beta.value <- beta.value[, samples]
		detecP <- detecP[, samples]
	}

	if (is.null(rownames(beta.value)) | is.null(rownames(detecP))) {
		cat("cannot figure out probe names.\n")
		return (NULL)
	}

	probes.X.hm450k <- probes.HM450k.X[probes.HM450k.X %in% rownames(beta.value)]
	probes.Y.hm450k <- probes.HM450k.Y[probes.HM450k.Y %in% rownames(beta.value)]
	probes.X.epic <- probes.EPIC.X[probes.EPIC.X %in% rownames(beta.value)]
	probes.Y.epic <- probes.EPIC.Y[probes.EPIC.Y %in% rownames(beta.value)]

	if(length(probes.X.epic) > length(probes.X.hm450k)) {
		probes.X <- probes.X.epic
		probes.Y <- probes.Y.epic
		probes.noSNP.X <- probes.EPIC.X
		probes.noSNP.Y <- probes.EPIC.Y
	} else {
		probes.X <- probes.X.hm450k
		probes.Y <- probes.Y.hm450k
		probes.noSNP.X <- probes.HM450k.X
		probes.noSNP.Y <- probes.HM450k.Y
	}


	tab.prop.test.beta.X <- do.call(rbind, lapply(as.list(samples), function(x) table(cut(beta.value[probes.X, x], breaks=beta.intervals.X, include.lowest=FALSE))/length(probes.noSNP.X)))
	tab.prop.test.beta.Y <- do.call(rbind, lapply(as.list(samples), function(x) table(cut(beta.value[probes.Y, x], breaks=beta.intervals.Y, include.lowest=FALSE))/length(probes.noSNP.Y)))
	tab.prop.test.p.X <- do.call(rbind, lapply(as.list(samples), function(x) table(cut(log10(detecP[probes.X, x]+(1e-17)), breaks=p.intervals.X))/length(probes.noSNP.X)))
	tab.prop.test.p.Y <- do.call(rbind, lapply(as.list(samples), function(x) table(cut(log10(detecP[probes.Y, x]+(1e-17)), breaks=p.intervals.Y))/length(probes.noSNP.Y)))

	colnames(tab.prop.test.beta.X) <- paste("X", colnames(tab.prop.test.beta.X), sep=":")
	colnames(tab.prop.test.beta.Y) <- paste("Y", colnames(tab.prop.test.beta.Y), sep=":")
	colnames(tab.prop.test.p.X) <- paste("p.X", colnames(tab.prop.test.p.X), sep=":")
	colnames(tab.prop.test.p.Y) <- paste("p.Y", colnames(tab.prop.test.p.Y), sep=":")

	tab.prop.test <- cbind(tab.prop.test.beta.X, tab.prop.test.beta.Y, tab.prop.test.p.X, tab.prop.test.p.Y)
	rownames(tab.prop.test) <- samples
	return (tab.prop.test)
}


